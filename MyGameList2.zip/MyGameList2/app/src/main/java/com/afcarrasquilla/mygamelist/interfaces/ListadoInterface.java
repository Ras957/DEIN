package com.afcarrasquilla.mygamelist.interfaces;

public interface ListadoInterface {
    public interface View{
        void lanzarFormulario();
    }

    public interface Presenter{
        void OnClickAdd();
    }
}
