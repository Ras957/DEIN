package com.afcarrasquilla.mygamelist.views;

import android.app.DatePickerDialog;
import android.os.Bundle;

import com.afcarrasquilla.mygamelist.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.Calendar;

public class FormularioActivity extends AppCompatActivity {

    String TAG = "MyGameList/FormularioActivity";

    private Spinner spinner1;
    private Button bfecha;
    private EditText textFecha;
    private int dia;
    private int mes;
    private int ano;
    private Button guardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Nuevo Juego");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Spinner y sus campos
        spinner1 = (Spinner)findViewById(R.id.spinnerPlataforma) ;
        String [] opciones = {"Elige plataforma...", "PS4","XBOX","SWITCH","PC","Otro"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, opciones);
        spinner1.setAdapter(adapter);

        //boton fecha y calendario
        bfecha = (Button)findViewById((R.id.fechaButtom)) ;
        textFecha = (EditText)findViewById(R.id.FechaEditText) ;
        bfecha.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
               final Calendar c = Calendar.getInstance();
               dia = c.get(Calendar.DAY_OF_MONTH);
               mes = c.get(Calendar.MONTH);
               ano = c.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog = new DatePickerDialog(FormularioActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        textFecha.setText(dayOfMonth+"/"+month+"/"+year);
                    }
                },dia,mes,ano);
                datePickerDialog.show();
            }
        });


        //boton guardad
        guardar=(Button)findViewById(R.id.saveButton);
        guardar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
            }
        });

    }

    @Override
    protected void onStart(){
        super.onStart();
        Log.d(TAG, "Ejecutando onStart...");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d(TAG, "Ejecutando onResume...");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d(TAG, "Ejecutando onPause...");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d(TAG, "Ejecutando onStop...");
    }

    @Override
    protected void onRestart(){
        super.onRestart();
        Log.d(TAG, "Ejecutando onRestart...");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "Ejecutando onDestroy...");
    }

}
